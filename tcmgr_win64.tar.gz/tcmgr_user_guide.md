# ToolchainManager User Guide

## Description

A utility tool that helps managing several similar toolchains (like clang and gcc) installed on a computer.
This tool is heavily inspired by the Rust ecosystem's `rustup toolchain link` and `rustup override set` commands.

## Installation

1. Put the ToolchainManager executable file to a separate directory which is dedicated only to the ToolchainManager
2. Add that directory to the beginning of your system's permanent PATH enviroment variable
3. Restart Windows CommandPrompt, PowerShell or Linux Shell and execute `tcmgr --version` to see if the ToolchainManager works

## Command line arguments

Please, execute the `tcmgr --help` command to see a summary of accepted command line arguments.
